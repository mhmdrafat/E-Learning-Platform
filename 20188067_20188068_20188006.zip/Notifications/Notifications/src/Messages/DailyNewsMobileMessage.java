package Messages;

public class DailyNewsMobileMessage {
	
	public String prepareMessage(String placeHolders[]) {
		// code to replace place holders of this type
		return "";
	}
}
