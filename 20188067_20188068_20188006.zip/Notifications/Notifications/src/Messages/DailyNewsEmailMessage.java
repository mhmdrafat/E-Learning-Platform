package Messages;

public class DailyNewsEmailMessage {
	
	public String prepareMessage(String placeHolders[]) {
		// code to replace place holders of this type
		return "";
	}
}
