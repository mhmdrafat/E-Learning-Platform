public class AddExam implements CourseStrategy{
    private static final notifyOperation notfOpr=new notifyOperation();
    private Course course;
    AddExam(Course course)
    {
        this.course=course;
    }
    @Override
    public void doOperation(String name, String body)
    {

    }
}
