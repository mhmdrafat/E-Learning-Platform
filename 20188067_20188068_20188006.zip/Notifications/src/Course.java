import Gateways.Getway;
import Gateways.GetwayFactory;
import Messages.AbstractMessageFactory;
import Messages.Message;
import Messages.MessageFactoryProducer;
import Users.Observer;

import java.util.ArrayList;
import java.util.Objects;

public class Course {
	
	String name;
	String code;
	ArrayList<String> announcements;
	ArrayList<String> exams;
	ArrayList<String> grades;
    CourseStrategy operation;

	ArrayList<Observer> observersForEmailNotification;
	ArrayList<Observer> observersForSMSNotification;

//	ArrayList<Professor> professorsForEmailNotification;
//	ArrayList<Professor> professorsForSMSNotification;
//
//	ArrayList<TA> TAsForEmailNotification;
//	ArrayList<TA> TAsForSMSNotification;
//
//	ArrayList<Student> studentsForEmailNotification;
//	ArrayList<Student> studentsForSMSNotification;
	
	public Course(String name, String code) {
		super();
		this.name = name;
		this.code = code;
		
		announcements = new ArrayList<String>();
		exams = new ArrayList<String>();
		grades = new ArrayList<String>();



		observersForEmailNotification = new ArrayList<Observer>();
		observersForSMSNotification = new ArrayList<Observer>();
//		professorsForSMSNotification = new ArrayList<Professor>();

//		professorsForEmailNotification = new ArrayList<Professor>();
//		professorsForSMSNotification = new ArrayList<Professor>();
//
//		TAsForEmailNotification = new ArrayList<TA>();
//		TAsForSMSNotification = new ArrayList<TA>();
//
//		studentsForEmailNotification = new ArrayList<Student>();
//		studentsForSMSNotification = new ArrayList<Student>();
	}
	public void doOperation(CourseStrategy opration,String name,String body)
	{
//		CourseStrategy operation;
//		if(opr.equalsIgnoreCase("AddAssignment"))
//			operation=new AddAssignment(this);
//		else if(opr.equalsIgnoreCase("AddExam"))
//			operation=new AddExam(this);
//		else if(opr.equalsIgnoreCase("PostGrades"))
//			operation=new PostGrades(this);
//		else if(opr.equalsIgnoreCase("PostAnnouncement"))
//			operation=new PostAnnouncement(this);
//		else
//			return;
		operation.doOperation(name,body);
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public void subscribeObserverForEmailNotification(Observer observer) {
		observersForEmailNotification.add(observer);
	}
	
	public void subscribeObserverForSMSNotification(Observer observer) {
		observersForSMSNotification.add(observer);
	}
	
//	public void subscribeTAForEmailNotification(TA ta) {
//		TAsForEmailNotification.add(ta);
//	}
//
//	public void subscribeTAForSMSNotification(TA ta) {
//		TAsForSMSNotification.add(ta);
//	}
//
//	public void subscribeStudentForEmailNotification(Student student) {
//		studentsForEmailNotification.add(student);
//	}
//
//	public void subscribeStudentForSMSNotification(Student student) {
//		studentsForSMSNotification.add(student);
//	}
	
	
	
//	public void AddAssignment(String assignName, String assignBody) {
//		announcements.add(assignName);
//		String[] placeholders = new String[] {assignName, assignBody};
//		// do some logic here
//
//		notifyAllUsers(placeholders,"TaskAdded","Email");
//		notifyAllUsers(placeholders,"TaskAdded","Mobile");
////		notifyAllUsers(placeholders);
//	}
	
	// AddExam, PostGrades, PostAnnouncement  will be the same 

	public void notifyAllUsers(String[] placeholders,String msgType,String msgFactory,CourseStrategy.notifyOperation notfOpr) {
        Objects.requireNonNull(notfOpr);
		// notify users by email
		AbstractMessageFactory  msgFac=MessageFactoryProducer.getMessageFactory(msgFactory);
		Message msg=msgFac.getMessage(msgType);
		String notification = msg.prepareMessage(placeholders);
		
		// open connection for Email gateway and do some configurations to the object
		
//		EmailGateway emailGateway = new EmailGateway();
//		SMSGateway smsGetway=new SMSGateway();
		GetwayFactory getwayFactory= GetwayFactory.getInstance();
		Getway emailGateway=getwayFactory.getGetway("Email");
		Getway smsGeteway=getwayFactory.getGetway("SMS");
		for (Observer observer : observersForEmailNotification) {
			observer.notifyall(notification);
			emailGateway.sendMessage(msg, observer.getEmail());
			smsGeteway.sendMessage(msg,observer.getEmail());
		}

//		for (Professor professor : professorsForEmailNotification) {
//			professor.notifyall(notification);
//			emailGateway.sendMessage(notification, professor.getEmail());
//		}
//		for (TA ta : TAsForEmailNotification) {
//			ta.notifyTA(notification);
//			emailGateway.sendMessage(notification, ta.getEmail());
//		}
//
//		for (Student student : studentsForSMSNotification) {
//			student.notifyStudent(notification);
//			emailGateway.sendMessage(notification, student.getEmail());
//		}
	}
	
	
	
	
}
