package Gateways;

public class GetwayFactory {
    private static GetwayFactory instance;
    private GetwayFactory(){}
    public Getway getGetway(String getwayType)
    {
        if (getwayType.equalsIgnoreCase("Email"))
            return  new EmailGateway();
        else if (getwayType.equalsIgnoreCase("SMS"))
            return new SMSGateway();
        return null;
    }
    public static GetwayFactory getInstance()
    {
        if(instance==null)
            return  new GetwayFactory();
        return instance;
    }
}
