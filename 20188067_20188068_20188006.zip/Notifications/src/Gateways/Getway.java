package Gateways;

import Messages.Message;

public interface Getway {
    public void sendMessage(Message message, String user);
}
