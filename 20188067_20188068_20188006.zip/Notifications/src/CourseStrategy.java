public interface CourseStrategy {
    public static final class notifyOperation{protected notifyOperation(){}}
    public void doOperation(String name, String body);
}
