package Messages;

public class MessageFactoryProducer {
    public static AbstractMessageFactory getMessageFactory(String messageFactory)
    {
        if(messageFactory.equalsIgnoreCase("Email"))
            return EmailMessageFactory.getInstance();
        else if(messageFactory.equalsIgnoreCase("Mobile"))
            return MobileMessageFactory.getInstance();
        return null;
    }
}
