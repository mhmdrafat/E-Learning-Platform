package Messages;

public abstract class AbstractMessageFactory {
    public abstract Message getMessage(String messageType) ;
}
