package Messages;

public class TaskAddedMobileMessage implements Message{
	@Override
	public String prepareMessage(String placeHolders[]) {
		// code to replace place holders of this type
		return "";
	}
	
	
	public void addTeamDescription() {
		
	}
}
