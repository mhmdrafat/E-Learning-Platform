package Messages;

public class MobileMessageFactory extends AbstractMessageFactory{
    private static MobileMessageFactory instance;
    private MobileMessageFactory(){}
    @Override
    public Message getMessage(String messageType)
    {
        if(messageType.equalsIgnoreCase("DailyNews"))
            return new DailyNewsMobileMessage();
        else if (messageType.equalsIgnoreCase("GradesAnnouncement"))
            return new GradesAnnouncementMobileMessage();
        else if (messageType.equalsIgnoreCase("TaskAdded"))
            return new TaskAddedMobileMessage();
        return null;
    }
    public static MobileMessageFactory getInstance()
    {
        if(instance==null)
            return  new MobileMessageFactory();
        return instance;
    }
}
