package Messages;

public class EmailMessageFactory extends AbstractMessageFactory{

   private static EmailMessageFactory instance;
   private EmailMessageFactory(){}
    @Override
    public Message getMessage(String messageType)
    {
        if(messageType.equalsIgnoreCase("DailyNews"))
            return new DailyNewsEmailMessage();
        else if (messageType.equalsIgnoreCase("GradesAnnouncement"))
            return new GradesAnnouncementEmailMessage();
        else if (messageType.equalsIgnoreCase("TaskAdded"))
            return new TaskAddedEmailMessage();
        return null;
    }
    public static EmailMessageFactory getInstance()
    {
        if(instance==null)
            return  new EmailMessageFactory();
        return instance;
    }

}
