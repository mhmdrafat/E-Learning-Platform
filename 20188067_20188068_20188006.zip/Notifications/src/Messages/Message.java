package Messages;

public interface Message {
    public String prepareMessage(String placeHolders[]);
}
