package Users;

public interface Observer {
    public void notifyall(String message);

    String getEmail();
}
