public class PostAnnouncement implements CourseStrategy {
    private static final notifyOperation notfOpr=new notifyOperation();
    private Course course;
    PostAnnouncement(Course course)
    {
        this.course=course;
    }
    @Override
    public void doOperation(String name, String body)
    {

    }
}
