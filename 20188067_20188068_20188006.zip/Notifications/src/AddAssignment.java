
public class AddAssignment implements CourseStrategy{
    private static final notifyOperation notfOpr=new notifyOperation();
    private Course course;
    AddAssignment(Course course)
    {
        this.course=course;
    }
    @Override
    public void doOperation(String name, String body)
    {
        course.announcements.add(name);
        String[] placeholders = new String[] {name, body};
        // do some logic here
        course.notifyAllUsers(placeholders,"TaskAdded","Email",notfOpr);
        course.notifyAllUsers(placeholders,"TaskAdded","Mobile",notfOpr);
    }
}
